export type ProductType = {
  productId: number;
  productName: string;
  productPrice: number;
  productImage: string;
  productStock: number;
}