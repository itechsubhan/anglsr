import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { ProductService } from 'src/app/services/product.service';
import { ProductType } from 'src/types';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
  providers: [
    ProductService,
  ]
})
export class ProductListComponent implements OnInit {
  @Input() selectedCurrency!: string;
  plist: ProductType[] = [];
  
  constructor(private productService: ProductService) { }
  ngOnChanges(changes: SimpleChanges) : void {
    console.log('Changes:', changes);
  }

  ngOnInit(): void {
    this.getData();
  }
  addItem(data: any) {
    console.log(data)
  }

  getData() {
    this.productService.getProduct().subscribe(
      (data) => {
        console.log('SUCCESS', data);
        this.plist = data as ProductType[];
      },
      (error) => {
        console.log('ERROR', error);
      }
    );
  }

}
